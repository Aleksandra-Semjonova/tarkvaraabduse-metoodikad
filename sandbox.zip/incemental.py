class Patsient:
    def _init_(self, nimi, vanus):
        self.nimi = nimi 
        self.vanus = vanus 


class Haigla:
    patsiendiList = []
    arstideList = []

    def patsientideKuvamine(self):
        for index, elem in enumerate(self.patsiendiList):
            print('id: ', index, 'Nimi: ', elem.nimi, 'Vanus: ', elem.vanus)

    def arstideKuvamine(self):
        for index, elem in enumerate(self.arstideList):
            print('id: ', index, 'Nimi: ', elem.nimi, 'Vanus: ', elem.vanus)

class Patsient:
    def _init_(self, nimi, vanus):
        self.nimi = nimi
        self.vanus = vanus

class Arst:
    def _init_(self, nimi, vanus, eriala):
        self.nimi = nimi
        self.vanus = vanus
        self.eriala = eriala

Patsient1 = Patsient("Thomas", 77)
Patsient2 = Patsient("Piter", 88)
Arst1 = Arst("Muhamad", 25, "allergoloog")

haigla = Haigla()
haigla.patsiendiList.append(Patsient1)
haigla.patsiendiList.append(Patsient2)
haigla.arstideList.append(Arst1)
haigla.patsientideKuvamine()
haigla.arstideKuvamine()